@ModuleGen(name = "service", groupPackage = "io.swagger.server.api.service", useFutures = false)
package io.swagger.server.api.service;

import io.vertx.codegen.annotations.ModuleGen;
