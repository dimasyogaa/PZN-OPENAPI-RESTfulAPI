import 'package:swagger/api.dart';
import 'package:test/test.dart';


/// tests for AllApi
void main() {
  var instance = new AllApi();

  group('tests for AllApi', () {
    // Get All Todolist
    //
    // Get all active todolist by default
    //
    //Future<ArrayTodolist> todolistGet({ bool includeDone, String name }) async
    test('test todolistGet', () async {
      // TODO
    });

  });
}
