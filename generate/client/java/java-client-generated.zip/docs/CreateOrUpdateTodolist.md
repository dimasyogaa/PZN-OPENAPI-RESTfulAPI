# CreateOrUpdateTodolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**priority** | [**BigDecimal**](BigDecimal.md) |  | 
**tags** | **List&lt;String&gt;** |  |  [optional]
