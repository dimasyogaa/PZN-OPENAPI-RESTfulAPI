# Todolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**priority** | [**BigDecimal**](BigDecimal.md) |  |  [optional]
**tags** | **List&lt;String&gt;** |  |  [optional]
