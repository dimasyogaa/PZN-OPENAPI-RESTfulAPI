# TodoListResTfulApi.Todolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**priority** | **Number** |  | [optional] 
**tags** | **[String]** |  | [optional] 
