# TodoListResTfulApi.CreateOrUpdateTodolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | 
**priority** | **Number** |  | 
**tags** | **[String]** |  | [optional] 
