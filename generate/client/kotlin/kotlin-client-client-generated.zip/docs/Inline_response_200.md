# InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | [**kotlin.Boolean**](.md) |  |  [optional]
