# CreateOrUpdateTodolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**kotlin.String**](.md) |  | 
**priority** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  | 
**tags** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
