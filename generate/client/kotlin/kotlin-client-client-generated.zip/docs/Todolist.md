# Todolist

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | [**kotlin.String**](.md) |  |  [optional]
**name** | [**kotlin.String**](.md) |  |  [optional]
**priority** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  [optional]
**tags** | [**kotlin.Array&lt;kotlin.String&gt;**](.md) |  |  [optional]
